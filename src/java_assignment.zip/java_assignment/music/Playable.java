package java_assignment.music;

public interface Playable {
    void play();
}
